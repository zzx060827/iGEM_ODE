import assert from "node:assert/strict";
import test from "node:test";

async function render() {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request("http://localhost/", { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the SINEUP delivery design workspace", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assert.match(html, /<title>SINEUP Delivery Atlas<\/title>/i);
  assert.match(html, /疾病驱动的 AAV 空间递送设计/);
  assert.match(html, /疾病库/);
  assert.match(html, /器官特异性/);
  assert.match(html, /单次给药有效持续时间/);
  assert.match(html, /研究级设计工具，不是临床剂量建议/);
  assert.match(html, /最大质量守恒误差/);
  assert.match(html, /PBPK–空间 CNS–SINEUP ODE/);
  assert.match(html, /112 个模型点/);
  assert.match(html, /浅层、皮层和深部三级空间转运/);
  assert.match(html, /dE\/dt → dSINEUP\/dt → dP\/dt/);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape/);
});

test("includes initial disease, capsid, evidence and social metadata", async () => {
  const response = await render();
  const html = await response.text();

  assert.match(html, /Wolf-Hirschhorn 综合征/);
  assert.match(html, /个靶基因/);
  assert.match(html, /神经祖细胞区/);
  assert.match(html, /CNS 目标深度/);
  assert.match(html, /NSD2/);
  assert.match(html, /AAV9/);
  assert.match(html, /PHP\.eB/);
  assert.match(html, /CAP-B10/);
  assert.match(html, /探索性/);
  assert.match(html, /全部显示/);
  assert.match(html, /EN/);
  assert.match(html, /property="og:image" content="http:\/\/localhost(?::3000)?\/og\.png"/);
});
